import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from tqdm import tqdm
from sys import argv,exit
import os
import re
from pathlib import Path

import warnings
warnings.filterwarnings("ignore")

# argv[1] --> station.txt
# argv[2] --> ROU-BSP DATA xlsx file
# argv[3] --> Freight train Traversal Details txt file

def generate_dt_data(Arr,Dep,Dist):
    """ Given --> (Arrival | Depart | Dist) Series/List
      Returns time and distance for plotting D-T graph"""
    assert len(Arr) == len(Dep) and len(Arr) == len(Dist)
    time = []
    dist = []

    for i in range(len(Arr)):
        time.append(Arr[i])
        dist.append(Dist[i])
        time.append(Dep[i])
        dist.append(Dist[i])

    return time,dist

def to_MM(HHMMSS):
    hh = 0
    HHMMSS = str(HHMMSS)
    ss = int(HHMMSS[-2:])
    mm = int(HHMMSS[-4:-2])
    if len(HHMMSS) > 4:
        hh = int(HHMMSS[:-4])

    return hh*60+mm+ss/60

if len(argv)<3:
  print('Need station.txt and ROU-BSP data as input.')
  exit()

print('Reading Station.txt')
stndist = pd.read_csv(argv[1],delim_whitespace=True)   
stndist['dist'] = (stndist['startKM']+stndist['endKM'])/2

print('Reading ROU-BSP data')
data = pd.read_csv(argv[2])

if len(argv) == 4:
    print('Reading traversal details')
    trav = pd.read_csv(argv[3],delimiter='\t')
    trav.reset_index(inplace=True)

    freight_trav = dict()

    for i in range(trav.shape[0]):
        trn_id = trav.iloc[i,0]
        stsn = list()
        arr = list()
        dept = list()

        st_indx = 9
        arr_indx = 12
        dep_indx = 13
        while dep_indx < len(trav.iloc[i,:]):
            stsn.append(stndist[stndist['/*Name']==trav.iloc[i,:][st_indx]]['dist'].tolist()[0])
            arr.append(to_MM(int(trav.iloc[i,:][arr_indx])))
            dept.append(to_MM(int(trav.iloc[i,:][dep_indx])))
            st_indx += 6
            arr_indx += 6
            dep_indx += 6 
        freight_trav.update({trn_id:generate_dt_data(arr,dept,stsn)})

# Converting times from seconds to minutes
data[['WTTARVL','WTTDPRT','WTTNEXTARVL']] = data[['WTTARVL','WTTDPRT','WTTNEXTARVL']].apply(lambda x : x/60)
data

train_plt_dat = dict()

for trnid in tqdm(data['TRAINID'].unique(),desc='Reading Files'):
    trainsch = data[data['TRAINID']==trnid][['STTNCODE','WTTARVL','WTTDPRT']]
    dist = []
    for stn in trainsch['STTNCODE']:
      dist.append(stndist[stndist['/*Name']==stn]['dist'].tolist()[0])
    trainsch['DIST'] = dist
    trainsch.reset_index(inplace=True)

    time,dist = generate_dt_data(trainsch['WTTARVL'],trainsch['WTTDPRT'],trainsch['DIST'])

    if dist[0]<dist[-1]:
        train_plt_dat.update({trnid : [time,dist,'up']})
    else:
        train_plt_dat.update({trnid : [time,dist,'down']})

fig = go.Figure()

fig.update_layout(
    yaxis = dict(
        tickmode = 'array',
        tickvals = stndist['dist'],
        ticktext = stndist['/*Name'],
        # range = [410,517],
        title = 'Stations'
    ),
    width = 1900,
    height = 900,
    xaxis = dict(
        rangeslider = {'visible' : True},
        # range = [0,800],
        title = 'Time'
    )
)

# for i in [1,2,3]:
#     fig.add_annotation(x=1440*i,y=730,text = 'day'+str(i),showarrow=False)
#     fig.add_vline(1440*i,line=dict(color='black',dash='dash'))

is_first = True
for train in list(train_plt_dat.keys()):
    if train_plt_dat[train][2] == 'up':
        if is_first:
            fig.add_trace(go.Scatter(x=train_plt_dat[train][0],y=train_plt_dat[train][1],mode='lines',line=dict(color = 'red'),name='Passenger train',legendgroup="p_train"))
        else:
            fig.add_trace(go.Scatter(x=train_plt_dat[train][0],y=train_plt_dat[train][1],mode='lines',line=dict(color = 'red'),name='Passenger train',legendgroup="p_train",showlegend=False))
        is_first = False

if len(argv) == 4:
    is_first  = True
    for train in list(freight_trav.keys()):
        if is_first:
            fig.add_trace(go.Scatter(x=freight_trav[train][0],y=freight_trav[train][1],mode='lines',line=dict(color = 'green'),name='Freight train',legendgroup="f_train"))
            is_first = False
        else:
            fig.add_trace(go.Scatter(x=freight_trav[train][0],y=freight_trav[train][1],mode='lines',line=dict(color = 'green'),name='Freight train',legendgroup="f_train",showlegend=False))


fig.show()



# fig = go.Figure()
# fig.add_trace(go.Scatter(x=x1,y=y1,mode='lines+markers',line=dict(color = 'red')))
# fig.add_trace(go.Scatter(x=x1,y=y2,mode='lines+markers',line=dict(color = 'red')))
# fig.show()
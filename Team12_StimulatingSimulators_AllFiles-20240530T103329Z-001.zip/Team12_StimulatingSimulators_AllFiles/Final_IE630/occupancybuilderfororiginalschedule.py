import pandas as pd
import numpy as np
from pathlib import Path
from sys import argv,exit
import os
from pathlib import Path
import re



# # delay = {"train":[15625 for i in range(1,15)],
# #          "Dmr":[round(i *60)  for i in np.random.uniform(low=0, high=10, size=14)],
# #          'Pasg':[round(i*60 ) for i in np.random.uniform(low=10, high=20, size=14)],
# #           'Pec':[round(i *60)  for i in np.random.uniform(low=20, high=30, size=14)],
# #           'Kugt':[round(i *60)  for i in np.random.uniform(low=30, high=40, size=14)], 
# #           'Nlkt':[round(i *60)  for i in np.random.uniform(low=40, high=50, size=14)], 
# #           'Manu':[round(i *60)  for i in np.random.uniform(low=50, high=60, size=14)], 
# #           'Skap':[round(i *60)  for i in np.random.uniform(low=60, high=70, size=14)],
# #             'Jwnr':[round(i*60 )  for i in np.random.uniform(low=70, high=80, size=14)],
# #        'Absa':[round(i*60 )  for i in np.random.uniform(low=80, high=90, size=14)],
# #          'Mgkm':[round(i*60 )  for i in np.random.uniform(low=90, high=100, size=14)], 
# #          'Tlmr':[round(i *60)  for i in np.random.uniform(low=100, high=110, size=14)], 
# #          'Jrna':[round(i*60 )  for i in np.random.uniform(low=110, high=120, size=14)], 
# #          'Jgnr':[round(i *60)  for i in np.random.uniform(low=120, high=130, size=14)], 
# #          'Agtl':[round(i*60 )  for i in np.random.uniform(low=130, high=140, size=14)]}

# delay_data = pd.read_csv('./master3traindelay.csv', index_col=0)
# sched_data = pd.read_csv('./dharma.csv')
# trainids = delay_data['train'].unique()
# for trainid in trainids:
#     if trainid in sched_data['TRAINNUMBER'].values:
#         matching_indices = delay_data[delay_data['train']==trainid].index.tolist()
#         sample_index = np.random.choice(matching_indices)
#         row = delay_data.loc[[sample_index],:]
#         for col in row.columns:
#             if col != 'train' and col != 'Agtl':
#                 correct_index = sched_data[(sched_data['TRAINNUMBER'] == trainid) & (sched_data['STTNCODE'] == col)].index
#                 sched_data.at[correct_index[0], 'WTTDPRT'] += row[col].values[0]
#                 if sched_data.at[correct_index[0], 'WTTARVL'] < (sched_data.at[correct_index[0], 'WTTDPRT'] - 120):
#                     sched_data.at[correct_index[0], 'WTTARVL'] = (sched_data.at[correct_index[0], 'WTTDPRT'] - 120)
#             if col == 'Agtl':
#                 correct_index = sched_data[(sched_data['TRAINNUMBER'] == trainid) & (sched_data['STTNCODE'] == col)].index
#                 sched_data.at[correct_index[0], 'WTTARVL'] += row[col].values[0]
#                 sched_data.at[correct_index[0]-1, 'WTTNEXTARVL'] = sched_data.at[correct_index[0], 'WTTARVL']
            

#         sequencing = sched_data[(sched_data['TRAINNUMBER'] == trainid)].index
#         # print(sequencing)
#         for i, ind in enumerate(sequencing):
#             if i != (len(sequencing)-1):
#                 sched_data.at[ind, 'WTTNEXTARVL'] = sched_data.at[ind+1, 'WTTARVL']
# sched_data.to_csv("tempdelay.csv", index = False)

def generate_dt_data(Arr,Dep,Dist):
    """ Given --> (Arrival | Depart | Dist) Series/List
      Returns time and distance for plotting D-T graph"""
    assert len(Arr) == len(Dep) and len(Arr) == len(Dist)
    time = []
    dist = []

    for i in range(len(Arr)):
        time.append(Arr[i])
        dist.append(Dist[i])
        time.append(Dep[i])
        dist.append(Dist[i])

    return time,dist

def to_MM(HHMMSS):
    hh = 0
    mm = 0
    ss = 0
    if HHMMSS != 0:
        HHMMSS = str(HHMMSS)
        ss = int(HHMMSS[-2:])
        if len(HHMMSS) > 2:
            mm = int(HHMMSS[-4:-2])
        if len(HHMMSS) > 4:
            hh = int(HHMMSS[:-4])

    return hh*60+mm+ss/60


def day_pattern(day):
    pat = list('.,.,.,.,.,.,.')
    pat[2*(day-1)] = '1'
    pat = "".join(pat)
    return pat

def HHMM(x):                # x is in minutes
    HH = str(x // 60)
    MM = str(x % 60)
    if len(HH) == 1:
        HH = '0'+HH
    if len(MM) == 1:
        MM = '0'+MM
    return str(HH)+str(MM)

loop_occs = {}
def decide_loop(stsn,nextblock,arr,dep):
    if int(str(nextblock)[-4]) == 0:                 # train going up
        if arr == dep:
            if loop_refs[stsn].upML not in loop_occs.keys():
                loop_occs.update({loop_refs[stsn].upML:[(arr,dep)]})
            else:
                loop_occs[loop_refs[stsn].upML].append((arr,dep))
            return loop_refs[stsn].upML
        else:
            loop_alloted = False
            if len(loop_refs[stsn].uploop) != 0:
                for loop in loop_refs[stsn].uploop:
                    if loop not in loop_occs.keys():
                        loop_alloted = True
                        loop_occs.update({loop:[(arr,dep)]})
                        return loop
                    else:
                        loop_ok = True
                        for i,occs in enumerate(loop_occs[loop]):
                            if (occs[0] <= arr and arr <= occs[1]) or (occs[0] <= dep and dep <= occs[1]):
                                loop_ok = False
                                break
                        if loop_ok == False:
                            continue
                        else:
                            loop_alloted = True
                            loop_occs[loop].append((arr,dep))
                            return loop    
            if len(loop_refs[stsn].commonloop) != 0 and loop_alloted == False:
                for loop in loop_refs[stsn].commonloop:
                    if loop not in loop_occs.keys():
                        loop_alloted = True
                        loop_occs.update({loop:[(arr,dep)]})
                        return loop
                    else:
                        loop_ok = True
                        for occs in loop_occs[loop]:
                            if (occs[0] <= arr and arr <= occs[1]) or (occs[0] <= dep and dep <= occs[1]):
                                loop_ok = False
                                break
                        if loop_ok == False:
                            continue
                        else:
                            loop_occs[loop].append((arr,dep))
                            return loop 

# goes to else only if len of common loop and uploop list is 0. change this s.t. else is run when loop not alloted yet.

            else:
                if loop_refs[stsn].upML not in loop_occs.keys():
                    loop_occs.update({loop_refs[stsn].upML:[(arr,dep)]})
                else:
                    for occs in loop_occs[loop_refs[stsn].upML]:
                        if (occs[0] <= arr and arr <= occs[1]) or (occs[0] <= dep and dep <= occs[1]):
                            break
                    loop_occs[loop_refs[stsn].upML].append((arr,dep))
                return loop_refs[stsn].upML

                
    else:
        if arr == dep:
            if loop_refs[stsn].downML not in loop_occs.keys():
                loop_occs.update({loop_refs[stsn].downML:[(arr,dep)]})
            else:
                loop_occs[loop_refs[stsn].downML].append((arr,dep))
            return loop_refs[stsn].downML
        else:
            if len(loop_refs[stsn].downloop) != 0:
                for loop in loop_refs[stsn].downloop:
                    if loop not in loop_occs.keys():
                        loop_occs.update({loop:[(arr,dep)]})
                        return loop
                    else:
                        loop_ok = True
                        for occs in loop_occs[loop]:
                            if (occs[0] <= arr and arr <= occs[1]) or (occs[0] <= dep and dep <= occs[1]):
                                loop_ok = False
                                break
                        if loop_ok == False:
                            continue
                        loop_occs[loop].append((arr,dep))
                        return loop  
            if len(loop_refs[stsn].commonloop) != 0:
                for loop in loop_refs[stsn].commonloop:
                    if loop not in loop_occs.keys():
                        loop_occs.update({loop:[(arr,dep)]})
                        return loop
                    else:
                        loop_ok = True
                        for occs in loop_occs[loop]:
                            if (occs[0] <= arr and arr <= occs[1]) or (occs[0] <= dep and dep <= occs[1]):
                                loop_ok = False
                                break
                        if loop_ok == False:
                            continue
                        loop_occs[loop].append((arr,dep))
                        return loop
            else:
                if loop_refs[stsn].downML not in loop_occs.keys():
                    loop_occs.update({loop_refs[stsn].downML:[(arr,dep)]})
                else:
                    for occs in loop_occs[loop_refs[stsn].downML]:
                        if (occs[0] <= arr and arr <= occs[1]) or (occs[0] <= dep and dep <= occs[1]):
                            break
                    loop_occs[loop_refs[stsn].downML].append((arr,dep))
                return loop_refs[stsn].downML

class station:

    def __init__(self,Looplist) -> None:

        self.uploop = list()
        self.downloop = list()
        self.commonloop = list()
        self.upML = None
        self.downML = None

        for loop in Looplist:
            if int(str(loop)[-4]) == 0:                                           # dir -> up
                if int(str(loop)[-3]) == 0:                                       # ML
                    self.upML = loop
                else:                                                             # loop
                    self.uploop.append(loop)
            elif int(str(loop)[-4]) == 1:                                         # dir -> down
                if int(str(loop)[-3]) == 0:                                       # ML
                    self.downML = loop
                else:                                                             # loop
                    self.downloop.append(loop)
            else:                                                                 # dir -> common
                self.commonloop.append(loop)

        self.uploop.sort()
        self.downloop.sort()
        self.commonloop.sort()
        

pyth_dir = Path.cwd()
sim_in = pyth_dir.parent / 'simulator_input'
data_dir = pyth_dir.parent / 'Railway data for ROU BSP'
stations = pd.read_csv('./station.txt', delim_whitespace=True)
loops = pd.read_csv('./loop.txt',delim_whitespace=True, index_col=False)
blocks = pd.read_csv('./block.txt',delim_whitespace=True, index_col=False)
# print("LOOOPs---------------------")
# print(loops.head(10).T)
stsn = dict()
stations = pd.read_csv('./station.txt', delim_whitespace=True)
for indx in range(stations.shape[0]):
    stsn.update({stations.loc[indx,'/*Name'] : (stations.loc[indx,'startKM'] + stations.loc[indx,'endKM'])/2})

loop_refs = {}
for stncode in loops['Station-Code'].unique():
    loop_refs.update({stncode: station(loops[loops['Station-Code']==stncode]['/*Loop-Number'].tolist())})

block_refs = {}
for i in range(blocks.shape[0]):
    prev = stations.loc[stations['endKM']==blocks.loc[i,'Starting-Mile-Post(Km)'],'/*Name'].tolist()[0]
    next = stations.loc[stations['startKM']==blocks.loc[i,'Ending-Mile-Post(Km)'],'/*Name'].tolist()[0]
    if blocks.loc[i,'Direction'] == 'up':
        block_refs.update({prev+str('-')+next : blocks.loc[i,'/*Block-Number']})
    else:
        block_refs.update({next+str('-')+prev : blocks.loc[i,'/*Block-Number']})

def Gen_Occupancy(occupancy,verbose = False):
    """
    Takes occupancy DataFrame as input and creates Occupancy.txt in the current folder
    columns of Occupancy DataFrame should be:
    'STTNCODE','BLCKSCTN','WTTARVL','WTTDPRT','WTTNEXTARVL'
    """

    occ = open('Maintenance.txt','w')
    occ.write('/*Loop/Block-Number Start-time End-time Allowed-Direction*/ \n\n')
   
    for i in range(occupancy.shape[0]):
        try:
            loopline = decide_loop(occupancy.loc[i,'STTNCODE'],block_refs[occupancy.loc[i,'BLCKSCTN']],occupancy.loc[i,'WTTARVL'],occupancy.loc[i,'WTTDPRT'])
            occ.write(str(loopline)+' "'+str(occupancy.loc[i,'WTTARVL'])+'" "'+str(occupancy.loc[i,'WTTDPRT'])+'" '+'"none" \n')
            if not pd.isna(occupancy.loc[i,'BLCKSCTN']):
                occ.write(str(block_refs[occupancy.loc[i,'BLCKSCTN']])+' "'+str(occupancy.loc[i,'WTTDPRT'])+'" "'+str(occupancy.loc[i,'WTTNEXTARVL'])+'" '+'"none" \n')
        except KeyError:
                print("Error aa gya")
                if verbose == True:
                    print(occupancy.loc[i,'BLCKSCTN'], 'Not in Infrastructure')


    occ.close()

def between(ele,R1,R2):
    if ele > R1  and ele < R2:
        return True
    else: 
        return False

def Create_conflic_report(occupancy):
    conflic_file = open('Train Conflicts in Scheduled data.txt','w')
    num_conflix = dict()

    for sect in occupancy['BLCKSCTN'].unique():
        conflic_file.write(f'For Section {sect} \n')
        sect_data = occupancy[occupancy['BLCKSCTN'] == sect].reset_index(drop=True)
    # display(sect_data)
        for indx in range(sect_data.shape[0]):
            trn1 = str(sect_data.loc[indx,'TRAINNUMBER'])
            trn1_strt = sect_data.loc[indx,'WTTDPRT']
            trn1_end = sect_data.loc[indx,'WTTNEXTARVL']

            for indx2 in range(indx+1,sect_data.shape[0]):
                trn2 = str(sect_data.loc[indx2,'TRAINNUMBER'])
                trn2_strt = sect_data.loc[indx2,'WTTDPRT']
                trn2_end = sect_data.loc[indx2,'WTTNEXTARVL']

                if between(trn2_strt,trn1_strt,trn1_end) or between(trn2_end,trn1_strt,trn1_end):
                    for trn in [trn1,trn2]:
                        if trn not in num_conflix.keys():
                            num_conflix.update({trn:1})
                        else:
                            num_conflix[trn] += 1
                    str1 = f'Found {trn1} time ({trn1_strt},{trn1_end}) and {trn2} time ({trn2_strt},{trn2_end}) using block {sect} simultaneously \n'
                    conflic_file.write(str1)
    conflic_file.write(f'Number of conflicting Trains : {len(num_conflix.keys())} \n')
    conflic_file.write('Trains and their number of conflicts \n')
    for trns in num_conflix.keys():
        conflic_file.write(f'{trns} : {num_conflix[trns]} \n')

    conflic_file.close()

def dayendtime(time):
    end = 1440
    while abs(time-end) > 1440 or time > end:
        end = end + 1440 

    return end

sched_data = pd.read_csv('./dharma.csv')
sched_data['TRAINNUMBER'] = sched_data['TRAINNUMBER'].apply(lambda x : '00' + str(x) if len(str(x)) == 3 else ('0'+str(x) if len(str(x)) == 4 else str(x)))
sched_data['TRAINID'] = sched_data['WTTDAYOFRUN'].astype(str) + sched_data['TRAINID'].astype(str)
# print("Sche data")
# print(sched_data.T)
# print("-----------------------------------------------------")
days = [3,4]
for i,d in enumerate(days):
    pattern = day_pattern(d)
    mask = list()
    for indx in range(sched_data.shape[0]):
        mask.append(bool(re.search(pattern,sched_data.loc[indx,'BLCKBUSYDAYS'])))

    day = sched_data[mask].copy()
    day['TRAINID'] = str(d) + day['TRAINID'].astype(str)
    day[['WTTARVL','WTTDPRT','WTTNEXTARVL']] = day[['WTTARVL','WTTDPRT','WTTNEXTARVL']].apply(lambda x : x % 86400 + i*86400) 

    if i == 0:
        combined = day
    else:
        combined = pd.concat([combined,day])
# print("combined")
# print("-----------------------------------------------------")
# print(combined)
occupancy = combined[['TRAINNUMBER','TRAINID','STTNCODE','BLCKSCTN','WTTARVL','WTTDPRT','WTTNEXTARVL']].copy()
occupancy[['WTTARVL','WTTDPRT','WTTNEXTARVL']] = combined[['WTTARVL','WTTDPRT','WTTNEXTARVL']].apply(lambda x : round(x/60,1))         # rounding
occupancy.reset_index(drop = True,inplace = True)

for indx in range(occupancy.shape[0]):
    if occupancy.loc[indx,'WTTARVL'] > occupancy.loc[indx,'WTTDPRT']:
        occupancy.loc[indx,'WTTDPRT'] = dayendtime(occupancy.loc[indx,'WTTARVL'])
    if occupancy.loc[indx,'WTTDPRT'] > occupancy.loc[indx,'WTTNEXTARVL']:
        occupancy.loc[indx,'WTTNEXTARVL'] = dayendtime(occupancy.loc[indx,'WTTDPRT'])

loop_occs = {}
Gen_Occupancy(occupancy)
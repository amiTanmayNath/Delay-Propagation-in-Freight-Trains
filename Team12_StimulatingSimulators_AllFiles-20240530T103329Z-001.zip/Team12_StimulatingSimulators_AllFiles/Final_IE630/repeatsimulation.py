import csv
import subprocess
import os
import time
import pandas as pd
import numpy as np
import shutil

# Function to edit the CSV file
def edit_csv(filename, outputname, freight, traversal):    
    subprocess.run("python occupancybuilder.py", shell=True)

    ## run for original schedule only
    # subprocess.run("python occupancybuilderfororiginalschedule.py", shell=True) 

    
    destination_folder = './delayfiles/'
    source_file = './tempdelay.csv'
    source_file2 = './freight-details.xls'
    source_file3 = './TraversalDetails.txt'

    #strategy 1
    tempdelay = pd.read_csv('tempdelay.csv') 

    #run only for original
    # tempdelay = pd.read_csv('dharma.csv')

    
    saatotrain = tempdelay[(tempdelay.STTNCODE == 'Dmr')][['TRAINNUMBER','WTTDPRT']]
    sorted_df = saatotrain.sort_values(by='WTTDPRT')
    selected_stations = [15664, 13173, 14620]
    startstationtime = None
    endstationtime = None
    for trainnumber in sorted_df.TRAINNUMBER:
        if trainnumber in selected_stations:
            startstationtime = sorted_df[sorted_df.TRAINNUMBER == trainnumber]['WTTDPRT'].values[0]
            break

    count = 0
    for trainnumber in sorted_df.TRAINNUMBER:
        if trainnumber in selected_stations:
            count+=1
            if count ==3:
                endstationtime = sorted_df[sorted_df.TRAINNUMBER == trainnumber]['WTTDPRT'].values[0]

    sorted_df = sorted_df[(sorted_df.WTTDPRT>=startstationtime) & (sorted_df.WTTDPRT<=endstationtime)] 

    with open('unscheduled.txt','w') as occ:
        occ.write('/*Train-No. Direction Start-Time(HHMM) Length(Km) Acceleration(m/s^2) Deceleration(m/s^2) Priority Maximum-Speed(kmph) Start-Loop End-Loop Number-Of-Halts Station Minutes-of-Halt Station Minutes-of-Halt*/\n')
        # Generate additional rows with start times ranging from 800 to 900
        traincount = 0
        timelist = sorted_df["WTTDPRT"].values
        timelist /= 60
        for i in range(len(timelist)-1):
            last_start_time = timelist[i]
            for start_time in range(int(last_start_time) + 20, int(timelist[i+1]), 20):
                traincount+=1
                row = f"{traincount} up {start_time} 0.5 0.08 0.15 1 70 10001 140001 0"
                occ.write(row + "\n")

    subprocess.run("java -jar -Xss600m .\Simulator-31st-July-c558138.jar non-interactive use-maintenance-block", shell = True)
    
    subprocess.run(r"python .\visualize.py .\station.txt .\tempdelay.csv .\TimeTableDetailed.xls", shell=True)

    #run only for original schdule
    # subprocess.run(r"python .\visualize.py .\station.txt .\dharma.csv .\TimeTableDetailed.xls", shell=True)

    # Check if the source file exists
    if os.path.exists(source_file):
        # Check if the destination folder exists, create it if not
        if not os.path.exists(destination_folder):
            print("No such folder.")
        # Combine the destination folder path with the new filename
        destination_file = os.path.join(destination_folder, outputname)
        # Copy the file to the destination folder and rename it
        shutil.copy(source_file, destination_file)
        print("File copied and renamed successfully.")
    else:
        print("Source file does not exist.")
    if os.path.exists(source_file2):
        # Check if the destination folder exists, create it if not
        if not os.path.exists(destination_folder):
            print("No such folder.")
        # Combine the destination folder path with the new filename
        destination_file = os.path.join(destination_folder, freight)
        # Copy the file to the destination folder and rename it
        shutil.copy(source_file2, destination_file)
        print("File copied and renamed successfully.")
    else:
        print("Source file does not exist.")
    
    if os.path.exists(source_file3):
        # Check if the destination folder exists, create it if not
        if not os.path.exists(destination_folder):
            print("No such folder.")
        # Combine the destination folder path with the new filename
        destination_file = os.path.join(destination_folder, traversal)
        # Copy the file to the destination folder and rename it
        shutil.copy(source_file3, destination_file)
        print("File copied and renamed successfully.")
    else:
        print("Source file does not exist.")

# Function to run the Windows command line command
def run_command(input_file, output_file):
    command = f'your_command_here {input_file} {output_file}'  # Replace 'your_command_here' with your actual command
    subprocess.run(command, shell=True)

# Function to read the output CSV file
def read_output_csv(filename):
    data = []
    with open(filename, newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            data.append(row)
    return data

# Main function to repeat the process
def main():
    # sequence = []
    # Define the number of iterations
    iterations = 2  # Change this to desired number of iterations

    for i in range(iterations):
            # Define file paths
        input_csv = f'dharma.csv'
        output_csv = f'tempdelay{i}.csv'
        # outputtxt = f'Maintenance{i}.txt'
        # outputxls = f'TimeTableDetailed{i}.xls'
        freight = f"freight-details{i}.xls"
        traversal = f"TraversalDetails{i}.txt"
        # Step 1: Edit the CSV file
        edit_csv(input_csv, output_csv, freight,traversal)

    #     # Step 2: Run the Windows command line command
    #     run_command(input_csv, output_csv)

    #     # Step 3: Read the output CSV file and store it in the sequence
    #     output_data = read_output_csv(output_csv)
    #     sequence.append(output_data)

    #     # Optional: Sleep for some time between iterations
    #     time.sleep(1)  # Adjust as needed

    # # Display the sequence
    # for i, data in enumerate(sequence):
    #     print(f"Iteration {i+1}: {data}")

if __name__ == '__main__':
    main()
